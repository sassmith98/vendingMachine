package listexample;

import java.util.ArrayList;
import java.util.List;

public class ListExample {

    public static void main(String[] args) {
        List<Integer> list = new ArrayList();
        for(int i = 0; i < 10; i++) {
            list.add(2*i);
        }
        System.out.println("Size " + list.size());
       
        list.add(5, 9);
        
        System.out.println("Size " + list.size());
        for(Integer integer: list) {
            System.out.print(" " + integer);
        }
    }    
}
